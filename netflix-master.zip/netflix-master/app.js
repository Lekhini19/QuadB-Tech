/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */
import React from 'react';
import MainScreen from './src/components/MainScreen';

export default () => <MainScreen />;
