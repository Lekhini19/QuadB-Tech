import { Text } from 'react-native';
import React from 'react';

export default () => <Text>asdfasdf</Text>;
