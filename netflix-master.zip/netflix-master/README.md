# netflix
Netflix app by React Native built by `redux`, `recompose` and `redux-observable`

### iOS
<p>
<image src=screenshots/ios-home.png style="display: inline; float: left; margin: 0 0;" width="280"/>
<image src=screenshots/ios-details.png style="display: inline; float: left; margin: 0 0;" width="280"/>
<image src=screenshots/ios-search.png style="display: inline; float: left; margin: 0 0;" width="280"/>
</p>

### Android
<p>
<image src=screenshots/android-home.png style="display: inline; float: left; margin: 20px;" width="300"/>
<image src=screenshots/android-details.png style="display: inline; float: left; margin: 20px;" width="300"/>
<p>
